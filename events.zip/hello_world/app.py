import json
import base64
from Crypto.PublicKey import RSA
import Crypto.Signature.PKCS1_v1_5 as sign_PKCS1_v1_5  # For signature/Verify Signature
from Crypto.Cipher import PKCS1_v1_5  # For encryption
from Crypto import Hash
from Crypto.Hash import SHA256
from Crypto.Cipher import AES
# import requests

pad = lambda s: bytes(s + (32 - len(s) % 32) * '#', 'utf-8')
SITE_AES_KEY = "c2l0ZV83ODUsdmVyXzIuMA==########"


def encrypt(self, raw):
    raw = pad(raw)
    iv = bytes(16 * '\x00', 'utf-8')
    cipher = AES.new(SITE_AES_KEY.encode('utf8'), AES.MODE_CBC, iv)
    return base64.b64encode(cipher.encrypt(raw))

def lambda_handler(event, context):
    data = json.loads(event['body'])

    # if data['cmd'] == '1':
    returnBody = " "



    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": returnBody,
            # "location": ip.text.replace("\n", "")
        }),
    }
